/**
 * Created by lindapembertonweb on 3/5/15.
 */
/*
Linda Pemberton
SDI section 02
March 5, 2015
Creating Variables and Output
 */

alert("This is about a proud wife, mother, and grandmother!!");//alert to show need for variables


var numberChildren = 5; //number variable
var numberGrandchildren = 4; //number variable

var isMarried = true; //boolean variable


console.log ("I have numerous children:"); //print comment to explain number variable
console.log (numberChildren);  //print number of children

var childrenAges = ["16", "23", "25", "26", "27"];  // array of children's ages
console.log ("Their ages vary:");  //print comment to list children's ages vary
console.log (childrenAges);  //print listing of children's ages


console.log ("My middle child\'s age is:")// console log to explain use of middle array
console.log (childrenAges[2]);//choose middle age child in array




console.log ("I also have several grandchildren:"); //print comment to explain number variable of total number of
    //grandchildren
console.log (numberGrandchildren);  //print the number of grandchildren to console


var happyPhrase = "I am happily married is:"; // string variable phrase
console.log (happyPhrase); //print happyPhrase
console.log (isMarried);  //print boolean answer




